package com.apiabastecimento.repository;

import org.springframework.stereotype.Repository;

@Repository
public interface IMaquinario extends JpaRepository<Maquinario, Long>{


}

