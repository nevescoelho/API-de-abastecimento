package com.apiabastecimento.repository;

import org.springframework.stereotype.Repository;

@Repository

public interface IBombacombustivel extends JpaRepository<Bombacombustivel, Long>{

	//save
	//delete
	//findAll()
}








	
	


