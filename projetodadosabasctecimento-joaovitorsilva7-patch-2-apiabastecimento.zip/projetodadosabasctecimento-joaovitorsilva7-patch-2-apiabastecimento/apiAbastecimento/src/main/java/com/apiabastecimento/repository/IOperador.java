package com.apiabastecimento.repository;

import org.springframework.stereotype.Repository;

@Repository

public interface IOperador extends JpaRepository<Operador, Long>  {

}
