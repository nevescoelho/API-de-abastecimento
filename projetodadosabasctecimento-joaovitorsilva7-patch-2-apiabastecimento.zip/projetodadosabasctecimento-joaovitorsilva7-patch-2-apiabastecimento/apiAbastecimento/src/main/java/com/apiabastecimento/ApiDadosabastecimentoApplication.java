package com.apiabastecimento;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiDadosabastecimentoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiDadosabastecimentoApplication.class, args);
		System.out.println("porta:1805");		
	}

}
