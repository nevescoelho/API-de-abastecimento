package com.apiabastecimento.repository;

import org.springframework.stereotype.Repository;

@Repository
public interface IFuncionario extends JpaRepository<Funcionario, Long>{

	
}
